// SPDX-License-Identifier: GPL-2.0-or-later
/*
 * NTFS kernel journal handling.
 *
 * Copyright (c) 2002-2007 Anton Altaparmakov
 */

#include <linux/blkdev.h>

#include "attrib.h"
#include "logfile.h"
#include "ntfs.h"

/*
 * ntfs_check_restart_page_header - check the page header for consistency
 * @vi:		LogFile inode to which the restart page header belongs
 * @rp:		restart page header to check
 * @pos:	position in @vi at which the restart page header resides
 *
 * Check the restart page header @rp for consistency and return 'true' if it is
 * consistent and 'false' otherwise.
 *
 * This function only needs NTFS_BLOCK_SIZE bytes in @rp, i.e. it does not
 * require the full restart page.
 */
static bool ntfs_check_restart_page_header(struct inode *vi,
		struct restart_page_header *rp, s64 pos)
{
	u32 logfile_system_page_size, logfile_log_page_size;
	u16 ra_ofs, usa_count, usa_ofs, usa_end = 0;
	bool have_usa = true;

	ntfs_debug("Entering.");
	/*
	 * If the system or log page sizes are smaller than the ntfs block size
	 * or either is not a power of 2 we cannot handle this log file.
	 */
	logfile_system_page_size = le32_to_cpu(rp->system_page_size);
	logfile_log_page_size = le32_to_cpu(rp->log_page_size);
	if (logfile_system_page_size < NTFS_BLOCK_SIZE ||
			logfile_log_page_size < NTFS_BLOCK_SIZE ||
			logfile_system_page_size &
			(logfile_system_page_size - 1) ||
			!is_power_of_2(logfile_log_page_size)) {
		ntfs_error(vi->i_sb, "LogFile uses unsupported page size.");
		return false;
	}
	/*
	 * We must be either at !pos (1st restart page) or at pos = system page
	 * size (2nd restart page).
	 */
	if (pos && pos != logfile_system_page_size) {
		ntfs_error(vi->i_sb, "Found restart area in incorrect position in LogFile.");
		return false;
	}
	/* We only know how to handle version 1.1. */
	if (le16_to_cpu(rp->major_ver) != 1 ||
	    le16_to_cpu(rp->minor_ver) != 1) {
		ntfs_error(vi->i_sb,
			"LogFile version %i.%i is not supported.  (This driver supports version 1.1 only.)",
			(int)le16_to_cpu(rp->major_ver),
			(int)le16_to_cpu(rp->minor_ver));
		return false;
	}
	/*
	 * If chkdsk has been run the restart page may not be protected by an
	 * update sequence array.
	 */
	if (ntfs_is_chkd_record(rp->magic) && !le16_to_cpu(rp->usa_count)) {
		have_usa = false;
		goto skip_usa_checks;
	}
	/* Verify the size of the update sequence array. */
	usa_count = 1 + (logfile_system_page_size >> NTFS_BLOCK_SIZE_BITS);
	if (usa_count != le16_to_cpu(rp->usa_count)) {
		ntfs_error(vi->i_sb,
			"LogFile restart page specifies inconsistent update sequence array count.");
		return false;
	}
	/* Verify the position of the update sequence array. */
	usa_ofs = le16_to_cpu(rp->usa_ofs);
	usa_end = usa_ofs + usa_count * sizeof(u16);
	if (usa_ofs < sizeof(struct restart_page_header) ||
			usa_end > NTFS_BLOCK_SIZE - sizeof(u16)) {
		ntfs_error(vi->i_sb,
			"LogFile restart page specifies inconsistent update sequence array offset.");
		return false;
	}
skip_usa_checks:
	/*
	 * Verify the position of the restart area.  It must be:
	 *	- aligned to 8-byte boundary,
	 *	- after the update sequence array, and
	 *	- within the system page size.
	 */
	ra_ofs = le16_to_cpu(rp->restart_area_offset);
	if (ra_ofs & 7 || (have_usa ? ra_ofs < usa_end :
			ra_ofs < sizeof(struct restart_page_header)) ||
			ra_ofs > logfile_system_page_size) {
		ntfs_error(vi->i_sb,
			"LogFile restart page specifies inconsistent restart area offset.");
		return false;
	}
	/*
	 * Only restart pages modified by chkdsk are allowed to have chkdsk_lsn
	 * set.
	 */
	if (!ntfs_is_chkd_record(rp->magic) && le64_to_cpu(rp->chkdsk_lsn)) {
		ntfs_error(vi->i_sb,
			"LogFile restart page is not modified by chkdsk but a chkdsk LSN is specified.");
		return false;
	}
	ntfs_debug("Done.");
	return true;
}

/*
 * ntfs_check_restart_area - check the restart area for consistency
 * @vi:		LogFile inode to which the restart page belongs
 * @rp:		restart page whose restart area to check
 *
 * Check the restart area of the restart page @rp for consistency and return
 * 'true' if it is consistent and 'false' otherwise.
 *
 * This function assumes that the restart page header has already been
 * consistency checked.
 *
 * This function only needs NTFS_BLOCK_SIZE bytes in @rp, i.e. it does not
 * require the full restart page.
 */
static bool ntfs_check_restart_area(struct inode *vi, struct restart_page_header *rp)
{
	u64 file_size;
	struct restart_area *ra;
	u32 ra_ofs, ra_len, ca_ofs;
	u8 fs_bits;

	ntfs_debug("Entering.");
	ra_ofs = le16_to_cpu(rp->restart_area_offset);
	ra = (struct restart_area *)((u8 *)rp + ra_ofs);
	/*
	 * Everything before ra->file_size must be before the first word
	 * protected by an update sequence number.  This ensures that it is
	 * safe to access ra->client_array_offset.
	 */
	if (ra_ofs + offsetof(struct restart_area, file_size) >
			NTFS_BLOCK_SIZE - sizeof(u16)) {
		ntfs_error(vi->i_sb,
			"LogFile restart area specifies inconsistent file offset.");
		return false;
	}
	/*
	 * Now that we can access ra->client_array_offset, make sure everything
	 * up to the log client array is before the first word protected by an
	 * update sequence number.  This ensures we can access all of the
	 * restart area elements safely.  Also, the client array offset must be
	 * aligned to an 8-byte boundary.
	 */
	ca_ofs = le16_to_cpu(ra->client_array_offset);
	if (((ca_ofs + 7) & ~7) != ca_ofs ||
			ra_ofs + ca_ofs > NTFS_BLOCK_SIZE - sizeof(u16)) {
		ntfs_error(vi->i_sb,
			"LogFile restart area specifies inconsistent client array offset.");
		return false;
	}
	/*
	 * The restart area must end within the system page size both when
	 * calculated manually and as specified by ra->restart_area_length.
	 * Also, the calculated length must not exceed the specified length.
	 */
	ra_len = ca_ofs + le16_to_cpu(ra->log_clients) *
			sizeof(struct log_client_record);
	if (ra_ofs + ra_len > le32_to_cpu(rp->system_page_size) ||
			ra_ofs + le16_to_cpu(ra->restart_area_length) >
			le32_to_cpu(rp->system_page_size) ||
			ra_len > le16_to_cpu(ra->restart_area_length)) {
		ntfs_error(vi->i_sb,
			"LogFile restart area is out of bounds of the system page size specified by the restart page header and/or the specified restart area length is inconsistent.");
		return false;
	}
	/*
	 * The ra->client_free_list and ra->client_in_use_list must be either
	 * LOGFILE_NO_CLIENT or less than ra->log_clients or they are
	 * overflowing the client array.
	 */
	if ((ra->client_free_list != LOGFILE_NO_CLIENT &&
			le16_to_cpu(ra->client_free_list) >=
			le16_to_cpu(ra->log_clients)) ||
			(ra->client_in_use_list != LOGFILE_NO_CLIENT &&
			le16_to_cpu(ra->client_in_use_list) >=
			le16_to_cpu(ra->log_clients))) {
		ntfs_error(vi->i_sb,
			"LogFile restart area specifies overflowing client free and/or in use lists.");
		return false;
	}
	/*
	 * Check ra->seq_number_bits against ra->file_size for consistency.
	 * We cannot just use ffs() because the file size is not a power of 2.
	 */
	file_size = le64_to_cpu(ra->file_size);
	fs_bits = 0;
	while (file_size) {
		file_size >>= 1;
		fs_bits++;
	}
	if (le32_to_cpu(ra->seq_number_bits) != 67 - fs_bits) {
		ntfs_error(vi->i_sb,
			"LogFile restart area specifies inconsistent sequence number bits.");
		return false;
	}
	/* The log record header length must be a multiple of 8. */
	if (((le16_to_cpu(ra->log_record_header_length) + 7) & ~7) !=
			le16_to_cpu(ra->log_record_header_length)) {
		ntfs_error(vi->i_sb,
			"LogFile restart area specifies inconsistent log record header length.");
		return false;
	}
	/* Dito for the log page data offset. */
	if (((le16_to_cpu(ra->log_page_data_offset) + 7) & ~7) !=
			le16_to_cpu(ra->log_page_data_offset)) {
		ntfs_error(vi->i_sb,
			"LogFile restart area specifies inconsistent log page data offset.");
		return false;
	}
	ntfs_debug("Done.");
	return true;
}

/*
 * ntfs_check_log_client_array - check the log client array for consistency
 * @vi:		LogFile inode to which the restart page belongs
 * @rp:		restart page whose log client array to check
 *
 * Check the log client array of the restart page @rp for consistency and
 * return 'true' if it is consistent and 'false' otherwise.
 *
 * This function assumes that the restart page header and the restart area have
 * already been consistency checked.
 *
 * Unlike ntfs_check_restart_page_header() and ntfs_check_restart_area(), this
 * function needs @rp->system_page_size bytes in @rp, i.e. it requires the full
 * restart page and the page must be multi sector transfer deprotected.
 */
static bool ntfs_check_log_client_array(struct inode *vi,
		struct restart_page_header *rp)
{
	struct restart_area *ra;
	struct log_client_record *ca, *cr;
	u16 nr_clients, idx;
	bool in_free_list, idx_is_first;

	ntfs_debug("Entering.");
	ra = (struct restart_area *)((u8 *)rp + le16_to_cpu(rp->restart_area_offset));
	ca = (struct log_client_record *)((u8 *)ra +
			le16_to_cpu(ra->client_array_offset));
	/*
	 * Check the ra->client_free_list first and then check the
	 * ra->client_in_use_list.  Check each of the log client records in
	 * each of the lists and check that the array does not overflow the
	 * ra->log_clients value.  Also keep track of the number of records
	 * visited as there cannot be more than ra->log_clients records and
	 * that way we detect eventual loops in within a list.
	 */
	nr_clients = le16_to_cpu(ra->log_clients);
	idx = le16_to_cpu(ra->client_free_list);
	in_free_list = true;
check_list:
	for (idx_is_first = true; idx != LOGFILE_NO_CLIENT_CPU; nr_clients--,
			idx = le16_to_cpu(cr->next_client)) {
		if (!nr_clients || idx >= le16_to_cpu(ra->log_clients))
			goto err_out;
		/* Set @cr to the current log client record. */
		cr = ca + idx;
		/* The first log client record must not have a prev_client. */
		if (idx_is_first) {
			if (cr->prev_client != LOGFILE_NO_CLIENT)
				goto err_out;
			idx_is_first = false;
		}
	}
	/* Switch to and check the in use list if we just did the free list. */
	if (in_free_list) {
		in_free_list = false;
		idx = le16_to_cpu(ra->client_in_use_list);
		goto check_list;
	}
	ntfs_debug("Done.");
	return true;
err_out:
	ntfs_error(vi->i_sb, "LogFile log client array is corrupt.");
	return false;
}

/*
 * ntfs_check_and_load_restart_page - check the restart page for consistency
 * @vi:		LogFile inode to which the restart page belongs
 * @rp:		restart page to check
 * @pos:	position in @vi at which the restart page resides
 * @wrp:	[OUT] copy of the multi sector transfer deprotected restart page
 * @lsn:	[OUT] set to the current logfile lsn on success
 *
 * Check the restart page @rp for consistency and return 0 if it is consistent
 * and -errno otherwise.  The restart page may have been modified by chkdsk in
 * which case its magic is CHKD instead of RSTR.
 *
 * This function only needs NTFS_BLOCK_SIZE bytes in @rp, i.e. it does not
 * require the full restart page.
 *
 * If @wrp is not NULL, on success, *@wrp will point to a buffer containing a
 * copy of the complete multi sector transfer deprotected page.  On failure,
 * *@wrp is undefined.
 *
 * Simillarly, if @lsn is not NULL, on success *@lsn will be set to the current
 * logfile lsn according to this restart page.  On failure, *@lsn is undefined.
 *
 * The following error codes are defined:
 *	-EINVAL	- The restart page is inconsistent.
 *	-ENOMEM	- Not enough memory to load the restart page.
 *	-EIO	- Failed to reading from LogFile.
 */
static int ntfs_check_and_load_restart_page(struct inode *vi,
		struct restart_page_header *rp, s64 pos, struct restart_page_header **wrp,
		s64 *lsn)
{
	struct restart_area *ra;
	struct restart_page_header *trp;
	int size, err;

	ntfs_debug("Entering.");
	/* Check the restart page header for consistency. */
	if (!ntfs_check_restart_page_header(vi, rp, pos)) {
		/* Error output already done inside the function. */
		return -EINVAL;
	}
	/* Check the restart area for consistency. */
	if (!ntfs_check_restart_area(vi, rp)) {
		/* Error output already done inside the function. */
		return -EINVAL;
	}
	ra = (struct restart_area *)((u8 *)rp + le16_to_cpu(rp->restart_area_offset));
	/*
	 * Allocate a buffer to store the whole restart page so we can multi
	 * sector transfer deprotect it.
	 */
	trp = kvzalloc(le32_to_cpu(rp->system_page_size), GFP_NOFS);
	if (!trp) {
		ntfs_error(vi->i_sb, "Failed to allocate memory for LogFile restart page buffer.");
		return -ENOMEM;
	}
	/*
	 * Read the whole of the restart page into the buffer.  If it fits
	 * completely inside @rp, just copy it from there.  Otherwise map all
	 * the required pages and copy the data from them.
	 */
	size = PAGE_SIZE - (pos & ~PAGE_MASK);
	if (size >= le32_to_cpu(rp->system_page_size)) {
		memcpy(trp, rp, le32_to_cpu(rp->system_page_size));
	} else {
		pgoff_t idx;
#if LINUX_VERSION_CODE >= KERNEL_VERSION(6, 6, 0)
		struct folio *folio;
#else
		struct page *page;
#endif
		int have_read, to_read;

		/* First copy what we already have in @rp. */
		memcpy(trp, rp, size);
		/* Copy the remaining data one page at a time. */
		have_read = size;
		to_read = le32_to_cpu(rp->system_page_size) - size;
		idx = (pos + size) >> PAGE_SHIFT;
		do {
#if LINUX_VERSION_CODE >= KERNEL_VERSION(6, 6, 0)
			folio = read_mapping_folio(vi->i_mapping, idx, NULL);
			if (IS_ERR(folio)) {
				ntfs_error(vi->i_sb, "Error mapping LogFile page (index %lu).",
						idx);
				err = PTR_ERR(folio);
				if (err != -EIO && err != -ENOMEM)
					err = -EIO;
				goto err_out;
			}
			size = min_t(int, to_read, PAGE_SIZE);
			memcpy((u8 *)trp + have_read, folio_address(folio), size);
			folio_put(folio);
#else
			page = read_mapping_page(vi->i_mapping, idx, NULL);
			if (IS_ERR(page)) {
				ntfs_error(vi->i_sb, "Error mapping LogFile page (index %lu).",
						idx);
				err = PTR_ERR(page);
				if (err != -EIO && err != -ENOMEM)
					err = -EIO;
				goto err_out;
			}
			size = min_t(int, to_read, PAGE_SIZE);
			memcpy((u8 *)trp + have_read, page_address(page), size);
			kunmap(page);
			put_page(page);
#endif
			have_read += size;
			to_read -= size;
			idx++;
		} while (to_read > 0);
	}
	/*
	 * Perform the multi sector transfer deprotection on the buffer if the
	 * restart page is protected.
	 */
	if ((!ntfs_is_chkd_record(trp->magic) || le16_to_cpu(trp->usa_count)) &&
	    post_read_mst_fixup((struct ntfs_record *)trp, le32_to_cpu(rp->system_page_size))) {
		/*
		 * A multi sector transfer error was detected.  We only need to
		 * abort if the restart page contents exceed the multi sector
		 * transfer fixup of the first sector.
		 */
		if (le16_to_cpu(rp->restart_area_offset) +
				le16_to_cpu(ra->restart_area_length) >
				NTFS_BLOCK_SIZE - sizeof(u16)) {
			ntfs_error(vi->i_sb,
				"Multi sector transfer error detected in LogFile restart page.");
			err = -EINVAL;
			goto err_out;
		}
	}
	/*
	 * If the restart page is modified by chkdsk or there are no active
	 * logfile clients, the logfile is consistent.  Otherwise, need to
	 * check the log client records for consistency, too.
	 */
	err = 0;
	if (ntfs_is_rstr_record(rp->magic) &&
			ra->client_in_use_list != LOGFILE_NO_CLIENT) {
		if (!ntfs_check_log_client_array(vi, trp)) {
			err = -EINVAL;
			goto err_out;
		}
	}
	if (lsn) {
		if (ntfs_is_rstr_record(rp->magic))
			*lsn = le64_to_cpu(ra->current_lsn);
		else /* if (ntfs_is_chkd_record(rp->magic)) */
			*lsn = le64_to_cpu(rp->chkdsk_lsn);
	}
	ntfs_debug("Done.");
	if (wrp)
		*wrp = trp;
	else {
err_out:
		kvfree(trp);
	}
	return err;
}

/*
 * ntfs_check_logfile - check the journal for consistency
 * @log_vi:	struct inode of loaded journal LogFile to check
 * @rp:		[OUT] on success this is a copy of the current restart page
 *
 * Check the LogFile journal for consistency and return 'true' if it is
 * consistent and 'false' if not.  On success, the current restart page is
 * returned in *@rp.  Caller must call kvfree(*@rp) when finished with it.
 *
 * At present we only check the two restart pages and ignore the log record
 * pages.
 *
 * Note that the MstProtected flag is not set on the LogFile inode and hence
 * when reading pages they are not deprotected.  This is because we do not know
 * if the LogFile was created on a system with a different page size to ours
 * yet and mst deprotection would fail if our page size is smaller.
 */
bool ntfs_check_logfile(struct inode *log_vi, struct restart_page_header **rp)
{
	s64 size, pos;
	s64 rstr1_lsn, rstr2_lsn;
	struct ntfs_volume *vol = NTFS_SB(log_vi->i_sb);
	struct address_space *mapping = log_vi->i_mapping;
#if LINUX_VERSION_CODE >= KERNEL_VERSION(6, 6, 0)
	struct folio *folio = NULL;
#else
	struct page *page = NULL;
#endif
	u8 *kaddr = NULL;
	struct restart_page_header *rstr1_ph = NULL;
	struct restart_page_header *rstr2_ph = NULL;
	int log_page_size, err;
	bool logfile_is_empty = true;
	u8 log_page_bits;

	ntfs_debug("Entering.");
	/* An empty LogFile must have been clean before it got emptied. */
	if (NVolLogFileEmpty(vol))
		goto is_empty;
	size = i_size_read(log_vi);
	/* Make sure the file doesn't exceed the maximum allowed size. */
	if (size > MaxLogFileSize)
		size = MaxLogFileSize;
	/*
	 * Truncate size to a multiple of the page cache size or the default
	 * log page size if the page cache size is between the default log page
	 * log page size if the page cache size is between the default log page
	 * size and twice that.
	 */
	if (DefaultLogPageSize <= PAGE_SIZE &&
	    DefaultLogPageSize * 2 <= PAGE_SIZE)
		log_page_size = DefaultLogPageSize;
	else
		log_page_size = PAGE_SIZE;
	/*
	 * Use ntfs_ffs() instead of ffs() to enable the compiler to
	 * optimize log_page_size and log_page_bits into constants.
	 */
	log_page_bits = ntfs_ffs(log_page_size) - 1;
	size &= ~(s64)(log_page_size - 1);
	/*
	 * Ensure the log file is big enough to store at least the two restart
	 * pages and the minimum number of log record pages.
	 */
	if (size < log_page_size * 2 || (size - log_page_size * 2) >>
			log_page_bits < MinLogRecordPages) {
		ntfs_error(vol->sb, "LogFile is too small.");
		return false;
	}
	/*
	 * Read through the file looking for a restart page.  Since the restart
	 * page header is at the beginning of a page we only need to search at
	 * what could be the beginning of a page (for each page size) rather
	 * than scanning the whole file byte by byte.  If all potential places
	 * contain empty and uninitialzed records, the log file can be assumed
	 * to be empty.
	 */
	for (pos = 0; pos < size; pos <<= 1) {
#if LINUX_VERSION_CODE >= KERNEL_VERSION(6, 6, 0)
		pgoff_t idx = pos >> PAGE_SHIFT;

		if (!folio || folio->index != idx) {
			if (folio) {
				kunmap_local(kaddr);
				folio_put(folio);
			}
			folio = read_mapping_folio(mapping, idx, NULL);
			if (IS_ERR(folio)) {
				ntfs_error(vol->sb, "Error mapping LogFile page (index %lu).",
						idx);
				goto err_out;
			}
		}
		kaddr = (u8 *)kmap_local_folio(folio, 0) + (pos & ~PAGE_MASK);
#else
		pgoff_t idx = pos >> PAGE_SHIFT;

		if (!page || page->index != idx) {
			if (page) {
				kunmap(page);
				put_page(page);
			}
			page = read_mapping_page(mapping, idx, NULL);
			if (IS_ERR(page)) {
				ntfs_error(vol->sb, "Error mapping LogFile page (index %lu).",
						idx);
				goto err_out;
			}
		}
		kaddr = (u8 *)page_address(page) + (pos & ~PAGE_MASK);
#endif
		/*
		 * A non-empty block means the logfile is not empty while an
		 * empty block after a non-empty block has been encountered
		 * means we are done.
		 */
		if (!ntfs_is_empty_recordp((__le32 *)kaddr))
			logfile_is_empty = false;
		else if (!logfile_is_empty)
			break;
		/*
		 * A log record page means there cannot be a restart page after
		 * this so no need to continue searching.
		 */
		if (ntfs_is_rcrd_recordp((__le32 *)kaddr))
			break;
		/* If not a (modified by chkdsk) restart page, continue. */
		if (!ntfs_is_rstr_recordp((__le32 *)kaddr) &&
				!ntfs_is_chkd_recordp((__le32 *)kaddr)) {
			if (!pos)
				pos = NTFS_BLOCK_SIZE >> 1;
			continue;
		}
		/*
		 * Check the (modified by chkdsk) restart page for consistency
		 * and get a copy of the complete multi sector transfer
		 * deprotected restart page.
		 */
		err = ntfs_check_and_load_restart_page(log_vi,
				(struct restart_page_header *)kaddr, pos,
				!rstr1_ph ? &rstr1_ph : &rstr2_ph,
				!rstr1_ph ? &rstr1_lsn : &rstr2_lsn);
		if (!err) {
			/*
			 * If we have now found the first (modified by chkdsk)
			 * restart page, continue looking for the second one.
			 */
			if (!pos) {
				pos = NTFS_BLOCK_SIZE >> 1;
				continue;
			}
			/*
			 * We have now found the second (modified by chkdsk)
			 * restart page, so we can stop looking.
			 */
			break;
		}
		/*
		 * Error output already done inside the function.  Note, we do
		 * not abort if the restart page was invalid as we might still
		 * find a valid one further in the file.
		 */
		if (err != -EINVAL) {
#if LINUX_VERSION_CODE >= KERNEL_VERSION(6, 6, 0)
			kunmap_local(kaddr);
			folio_put(folio);
#else
			kunmap(page);
			put_page(page);
#endif
			goto err_out;
		}
		/* Continue looking. */
		if (!pos)
			pos = NTFS_BLOCK_SIZE >> 1;
	}
#if LINUX_VERSION_CODE >= KERNEL_VERSION(6, 6, 0)
	if (folio) {
		kunmap_local(kaddr);
		folio_put(folio);
	}
#else
	if (page) {
		kunmap(page);
		put_page(page);
	}
#endif
	if (logfile_is_empty) {
		NVolSetLogFileEmpty(vol);
is_empty:
		ntfs_debug("Done.  (LogFile is empty.)");
		return true;
	}
	if (!rstr1_ph) {
		ntfs_error(vol->sb,
			"Did not find any restart pages in LogFile and it was not empty.");
		return false;
	}
	/* If both restart pages were found, use the more recent one. */
	if (rstr2_ph) {
		/*
		 * If the second restart area is more recent, switch to it.
		 * Otherwise just throw it away.
		 */
		if (rstr2_lsn > rstr1_lsn) {
			ntfs_debug("Using second restart page as it is more recent.");
			kvfree(rstr1_ph);
			rstr1_ph = rstr2_ph;
			/* rstr1_lsn = rstr2_lsn; */
		} else {
			ntfs_debug("Using first restart page as it is more recent.");
			kvfree(rstr2_ph);
		}
		rstr2_ph = NULL;
	}
	/* All consistency checks passed. */
	if (rp)
		*rp = rstr1_ph;
	else
		kvfree(rstr1_ph);
	ntfs_debug("Done.");
	return true;
err_out:
	kvfree(rstr1_ph);
	return false;
}

/*
 * ntfs_empty_logfile - empty the contents of the LogFile journal
 * @log_vi:	struct inode of loaded journal LogFile to empty
 *
 * Empty the contents of the LogFile journal @log_vi and return 'true' on
 * success and 'false' on error.
 *
 * This function assumes that the LogFile journal has already been consistency
 * checked by a call to ntfs_check_logfile() and that ntfs_is_logfile_clean()
 * has been used to ensure that the LogFile is clean.
 */
bool ntfs_empty_logfile(struct inode *log_vi)
{
	s64 vcn, end_vcn;
	struct ntfs_inode *log_ni = NTFS_I(log_vi);
	struct ntfs_volume *vol = log_ni->vol;
	struct super_block *sb = vol->sb;
	struct runlist_element *rl;
	unsigned long flags;
	int err;
	bool should_wait = true;
	char *empty_buf = NULL;
	struct file_ra_state *ra = NULL;

	ntfs_debug("Entering.");
	if (NVolLogFileEmpty(vol)) {
		ntfs_debug("Done.");
		return true;
	}

	/*
	 * We cannot use ntfs_attr_set() because we may be still in the middle
	 * of a mount operation.  Thus we do the emptying by hand by first
	 * zapping the page cache pages for the LogFile/DATA attribute and
	 * then emptying each of the buffers in each of the clusters specified
	 * by the runlist by hand.
	 */
	vcn = 0;
	read_lock_irqsave(&log_ni->size_lock, flags);
	end_vcn = (log_ni->initialized_size + vol->cluster_size_mask) >>
			vol->cluster_size_bits;
	read_unlock_irqrestore(&log_ni->size_lock, flags);
	truncate_inode_pages(log_vi->i_mapping, 0);
	down_write(&log_ni->runlist.lock);
	rl = log_ni->runlist.rl;
	if (unlikely(!rl || vcn < rl->vcn || !rl->length)) {
map_vcn:
		err = ntfs_map_runlist_nolock(log_ni, vcn, NULL);
		if (err) {
			ntfs_error(sb, "Failed to map runlist fragment (error %d).", -err);
			goto err;
		}
		rl = log_ni->runlist.rl;
	}
	/* Seek to the runlist element containing @vcn. */
	while (rl->length && vcn >= rl[1].vcn)
		rl++;

	err = -ENOMEM;
	empty_buf = kvzalloc(vol->cluster_size, GFP_NOFS);
	if (!empty_buf)
		goto err;

	memset(empty_buf, 0xff, vol->cluster_size);

	ra = kzalloc(sizeof(*ra), GFP_NOFS);
	if (!ra)
		goto err;

#if LINUX_VERSION_CODE >= KERNEL_VERSION(6, 11, 0)
	file_ra_state_init(ra, sb->s_bdev->bd_mapping);
#else
	file_ra_state_init(ra, sb->s_bdev->bd_inode->i_mapping);
#endif
	do {
		s64 lcn;
		loff_t start, end;
		s64 len;

		/*
		 * If this run is not mapped map it now and start again as the
		 * runlist will have been updated.
		 */
		lcn = rl->lcn;
		if (unlikely(lcn == LCN_RL_NOT_MAPPED)) {
			vcn = rl->vcn;
			kvfree(empty_buf);
			empty_buf = NULL;
			kfree(ra);
			ra = NULL;
			goto map_vcn;
		}
		/* If this run is not valid abort with an error. */
		if (unlikely(!rl->length || lcn < LCN_HOLE))
			goto rl_err;
		/* Skip holes. */
		if (lcn == LCN_HOLE)
			continue;
		start = NTFS_CLU_TO_B(vol, lcn);
		len = rl->length;
		if (rl[1].vcn > end_vcn)
			len = end_vcn - rl->vcn;
		end = NTFS_CLU_TO_B(vol, lcn + len);

#if LINUX_VERSION_CODE >= KERNEL_VERSION(6, 11, 0)
		page_cache_sync_readahead(sb->s_bdev->bd_mapping, ra, NULL,
			start >> PAGE_SHIFT, (end - start) >> PAGE_SHIFT);
#else
		page_cache_sync_readahead(sb->s_bdev->bd_inode->i_mapping, ra, NULL,
			start >> PAGE_SHIFT, (end - start) >> PAGE_SHIFT);
#endif

		do {
			err = ntfs_bdev_write(sb, empty_buf, start,
						  vol->cluster_size);
			if (err) {
				ntfs_error(sb, "ntfs_bdev_write failed, err : %d\n", err);
				goto io_err;
			}

			/*
			 * Submit the buffer and wait for i/o to complete but
			 * only for the first buffer so we do not miss really
			 * serious i/o errors.  Once the first buffer has
			 * completed ignore errors afterwards as we can assume
			 * that if one buffer worked all of them will work.
			 */
			if (should_wait) {
				should_wait = false;
#if LINUX_VERSION_CODE >= KERNEL_VERSION(6, 11, 0)
				err = filemap_write_and_wait_range(sb->s_bdev->bd_mapping,
						start, start + vol->cluster_size);
#else
				err = filemap_write_and_wait_range(sb->s_bdev->bd_inode->i_mapping,
						start, start + vol->cluster_size);
#endif
				if (err)
					goto io_err;
			}
			start += vol->cluster_size;
		} while (start < end);
	} while ((++rl)->vcn < end_vcn);
	up_write(&log_ni->runlist.lock);
	kvfree(empty_buf);
	kfree(ra);
	truncate_inode_pages(log_vi->i_mapping, 0);
	/* Set the flag so we do not have to do it again on remount. */
	NVolSetLogFileEmpty(vol);
	ntfs_debug("Done.");
	return true;
io_err:
	ntfs_error(sb, "Failed to write buffer.  Unmount and run chkdsk.");
	goto dirty_err;
rl_err:
	ntfs_error(sb, "Runlist is corrupt.  Unmount and run chkdsk.");
dirty_err:
	NVolSetErrors(vol);
	err = -EIO;
err:
	kvfree(empty_buf);
	kfree(ra);
	up_write(&log_ni->runlist.lock);
	ntfs_error(sb, "Failed to fill LogFile with 0xff bytes (error %d).",
			-err);
	return false;
}
